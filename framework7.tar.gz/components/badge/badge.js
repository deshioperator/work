export default {
  name: 'badge',
};
